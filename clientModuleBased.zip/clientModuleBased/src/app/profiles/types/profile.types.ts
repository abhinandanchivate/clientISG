
export const PROFILE_ACTION_TYPES = {
    "CREATE_PROFILE_ACTION" : "[Profile] CreateProfileAction",
    "CREATE_PROFILE_FAIL" : "[Profile] Create Profile Fail",
    "CREATE_PROFILE_SUCCESS" : "[Profile] Create Profile Success",

    "GET_CURRENT_PROFILE_ACTION" : "[Profile] Get Current Profile Action",
    "GET_CURRENT_PROFILE_FAIL" : "[Profile] Get Current Profile Fail",
    "GET_CURRENT_PROFILE_SUCCESS" : "[Profile] Get Current Profile Success",
}
