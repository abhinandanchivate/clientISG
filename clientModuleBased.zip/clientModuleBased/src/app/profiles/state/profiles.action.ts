import { createAction, props } from '@ngrx/store';
import { PROFILE_ACTION_TYPES } from '../types/profile.types';
import { IProfile, ProfileProps } from '../models/iprofile';

export const createProfileAction = createAction(
  PROFILE_ACTION_TYPES.CREATE_PROFILE_ACTION,
  props<{ profile: IProfile }>()
);
export const  createProfileActionSuccess = createAction(
  PROFILE_ACTION_TYPES.CREATE_PROFILE_SUCCESS,
  props<{ response: ProfileProps }>()
);
export const createProfileActionFail = createAction(
  PROFILE_ACTION_TYPES.CREATE_PROFILE_FAIL,
  props<{ errorResponse: string }>()
);
 
export const getProfileAction = createAction(
  PROFILE_ACTION_TYPES.GET_CURRENT_PROFILE_ACTION
);
export const  getProfileActionSuccess = createAction(
  PROFILE_ACTION_TYPES.GET_CURRENT_PROFILE_SUCCESS,
  props<{ response: ProfileProps }>()
);
export const getProfileActionFail = createAction(
  PROFILE_ACTION_TYPES.GET_CURRENT_PROFILE_FAIL,
  props<{ errorResponse: any }>()
);