// holding signle profile and current user profile amd holding multiple profile state.

import { IProfile, ProfileDetails } from '../models/iprofile';

export interface ProfileState {
  currentProfile: ProfileDetails | null;
  allProfiles: ProfileDetails[];
  error: string | null;
  loading: boolean;
  token?: string;
}

export const initialProfileState: ProfileState = {
  currentProfile: null,           // Initially, no profile is loaded
  allProfiles: [],                // Start with an empty array of profiles
  error: null,                    // No errors initially
  loading: false                  // Not loading initially  
};
