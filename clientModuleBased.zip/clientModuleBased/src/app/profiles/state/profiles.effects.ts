import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { ProfileService } from '../services/profile.service';
import { Router } from '@angular/router';
import { createProfileAction, createProfileActionSuccess, createProfileActionFail, getProfileActionSuccess, getProfileActionFail, getProfileAction  } from './profiles.action';
import { catchError, map, merge, mergeMap, of, switchMap } from 'rxjs';
import { ProfileProps } from '../models/iprofile';

@Injectable()
export class ProfileEffect {
  constructor(
    private action$: Actions,
    private profileService: ProfileService,
    private router: Router
  ) {}

  createProfile$ = createEffect(() =>
    this.action$.pipe(
      ofType(createProfileAction),
      mergeMap(({ profile }) =>
        this.profileService.createProfile({ ...profile }).pipe(
          map(
            (createdProfile: ProfileProps) =>{
              this.router.navigate(['/profiles/display-profile']);
             return  createProfileActionSuccess({ response: createdProfile }) // Ensure the property is `profile`
            }
          ),
          catchError((error) =>
            of(createProfileActionFail({ errorResponse: error.message }))
          )
        )
      )
    )
  );

  getProfile$ = createEffect(() =>
    this.action$.pipe(
      ofType(getProfileAction),
      mergeMap(() =>
        this.profileService.getProfile().pipe(
          map(
            (profile: ProfileProps) =>
              getProfileActionSuccess({ response: profile }) // Ensure the property is `profile`
          ),
          catchError((error) =>
            of(getProfileActionFail({ errorResponse: error.message }))
          )
        )
      )
    )
  );
}
