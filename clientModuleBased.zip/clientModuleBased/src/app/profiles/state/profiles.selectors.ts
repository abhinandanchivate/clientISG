import { createFeatureSelector, createSelector } from '@ngrx/store';
import { ProfileState } from './profiles.state';
import { AppState } from '../../globalstate/app.state';

// Selectors will return the data from the profile state.
// selectProfileState can only be used in the profile module.
export const selectProfileState =
  createFeatureSelector<ProfileState>('profile');

export const selectCurrentProfile = createSelector(
  selectProfileState,
  (state: AppState["profile"]) => {
    console.log(state);
    console.log(state.currentProfile);
    return state.currentProfile
  }
);

export const selectCurrentProfileError = createSelector(
  selectProfileState,
  (error) => error.error
);
