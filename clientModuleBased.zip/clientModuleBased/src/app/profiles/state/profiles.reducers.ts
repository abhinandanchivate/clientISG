import { createReducer, on } from "@ngrx/store";
import { initialProfileState, ProfileState } from "./profiles.state";
import { createProfileAction, createProfileActionSuccess, createProfileActionFail, getProfileActionSuccess, getProfileActionFail, getProfileAction } from "./profiles.action";


export const profileReducer = createReducer(initialProfileState,
    on(createProfileAction, getProfileAction, (profileState: ProfileState) =>({
        ...profileState, // data which we get for the rest calls
        loading: true,
    })),
    on(createProfileActionSuccess, getProfileActionSuccess, (state: ProfileState, {response}) => ({
        ...state, // data which we get for the rest calls
       profiles:  [...state.allProfiles],
       currentProfile: response, 
       loading: false,
        error: null,
    })),
    on(createProfileActionFail, getProfileActionFail, (state, { errorResponse }) => ({
        ...state,
        loading: false,
        error: errorResponse,
      }))
);
 
 