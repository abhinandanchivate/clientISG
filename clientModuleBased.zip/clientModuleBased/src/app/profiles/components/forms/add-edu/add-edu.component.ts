import { Component } from '@angular/core';
import { IEducation } from '../../../models/ieduction';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { logValidationErrors } from '../../../../shared/utils/logValidators';

@Component({
  selector: 'app-add-edu',
  templateUrl: './add-edu.component.html',
  styleUrl: './add-edu.component.css',
})
export class AddEduComponent {
  submitted = false;
  ieducation: IEducation = {
    school: '',
    degree: '',
    fieldofstudy: '',
    commonProfile: { from: '', to: '', current: false, description: '' },
  };
  educationForm: FormGroup;
  constructor(private fb: FormBuilder) {
    this.educationForm = this.fb.group({
      school: ['', Validators.required],
      degree: ['', Validators.required],
      fieldofstudy: ['', Validators.required],
      commonProfile: this.fb.group({
        from: ['', Validators.required],
        to: ['', Validators.required],
        current: [false],
        description: [''],
      }),
    });
  }

  onSubmit() {
    this.submitted = true;
    if (this.onCheckValidForm()) {
      console.log(this.educationForm.value);
      this.submitted = false;
    } else {
      console.log('Invalid form');
      logValidationErrors(this.educationForm);
    }
  }

  onCheckValidForm() {
    return this.educationForm.valid;
  }

  get school() { return this.educationForm.controls['school']; }
  get degree() { return this.educationForm.controls['degree']; }
}
