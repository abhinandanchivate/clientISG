import { Component } from '@angular/core';

import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { IExperience } from '../../../models/iexperience';
import { logValidationErrors } from '../../../../shared/utils/logValidators';

@Component({
  selector: 'app-add-exp',
  templateUrl: './add-exp.component.html',
  styleUrl: './add-exp.component.css'
})
export class AddExpComponent {
  submitted = false;
  iexperience: IExperience = { title: '', company: '', location: '', 
    commonProfile : { from: '', to: '', current: false, description: '' } };
  experienceForm :FormGroup;
  constructor(private fb: FormBuilder) {
    this.experienceForm = this.fb.group({
      title: ['', Validators.required],
      company: ['', Validators.required],
      location: ['', Validators.required],
      commonProfile: this.fb.group({
        from: ['', Validators.required],
        to: ['', Validators.required],
        current: [false],
        description: ['']
      }),
    });
  }

  onSubmit() {
    this.submitted = true;
    if(this.onCheckValidForm()){
      console.log(this.experienceForm.value);
      this.submitted = false;
    } else {
      console.log("Invalid form");
      logValidationErrors(this.experienceForm);
    }
  }

  onCheckValidForm(){
    return this.experienceForm.valid;
  }

  get title() { return this.experienceForm.controls['title']; }
  get company() { return this.experienceForm.controls['company']; }
}
