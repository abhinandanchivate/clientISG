import { Component } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { IProfile } from '../../../models/iprofile';
import { logValidationErrors } from '../../../../shared/utils/logValidators';
import { Store } from '@ngrx/store';
import { AppState } from '../../../../globalstate/app.state';
import { createProfileAction } from '../../../state/profiles.action';

@Component({
  selector: 'app-create-profile',
  templateUrl: './create-profile.component.html',
  styleUrl: './create-profile.component.css'
})
export class CreateProfileComponent {
  submitted = false;
  iProfile: IProfile = { status: '', company: '', website: '', location: '', skills: '', githubusername: '', bio: '', social: {} };
  createProfileForm: FormGroup;
  constructor(private fb: FormBuilder, private store: Store<{app: AppState}>) { 
    this.createProfileForm = this.fb.group({
      status: ['', [Validators.required]],
      company: ['' ],
      website: [''],
      location: [''],
      skills: ['', [Validators.required]],
      githubusername: [''],
      bio: [''], 
      social: this.fb.group({
        twitter: [''],
        facebook: [''],
        linkedin: [''],
        youtube: [''],
        instagram: ['']
      })
    });
  }

  
    // Getters for easy access of FormControl's
    // ========================================
    get status() { return this.createProfileForm.controls['status']; }
    get skills() { return this.createProfileForm.controls['skills']; }
    

  profileSubmit() {
    this.submitted = true;
    if(this.isFormDataValid()){
      this.iProfile = this.createProfileForm.value;
      this.store.dispatch(createProfileAction({profile: this.iProfile}));
      console.log(this.iProfile);
      this.submitted = false;
    }else {
      console.log('Form is not valid');
      logValidationErrors(this.createProfileForm);
    }
  }

  isFormDataValid() : boolean{
    return this.createProfileForm.valid;
  }

}
