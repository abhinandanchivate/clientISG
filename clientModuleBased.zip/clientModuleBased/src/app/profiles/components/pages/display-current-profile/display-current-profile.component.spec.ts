import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DisplayCurrentProfileComponent } from './display-current-profile.component';

describe('DisplayCurrentProfileComponent', () => {
  let component: DisplayCurrentProfileComponent;
  let fixture: ComponentFixture<DisplayCurrentProfileComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [DisplayCurrentProfileComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(DisplayCurrentProfileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
