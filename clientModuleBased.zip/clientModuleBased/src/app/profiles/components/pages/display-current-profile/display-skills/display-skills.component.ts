import { Component, Input, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';

@Component({
  selector: 'app-display-skills',
  templateUrl: './display-skills.component.html',
  styleUrl: './display-skills.component.css'
})
export class DisplaySkillsComponent implements OnInit {

  @Input() skills: string[] = [];

  constructor(private store:Store){

  }

  ngOnInit(): void {
    
  }


}
