import { Component, OnInit } from '@angular/core';
import { AppState } from '../../../../globalstate/app.state';
import { select, Store } from '@ngrx/store';
import { getProfileAction } from '../../../state/profiles.action';
import { Observable } from 'rxjs';
import { ProfileDetails } from '../../../models/iprofile';
import { selectCurrentProfile } from '../../../state/profiles.selectors';

@Component({
  selector: 'app-display-current-profile',
  templateUrl: './display-current-profile.component.html',
  styleUrl: './display-current-profile.component.css'
})
export class DisplayCurrentProfileComponent implements OnInit {
    currentProfile$: Observable<ProfileDetails| null>;
    constructor(private store:Store){
      this.currentProfile$ = this.store.select(selectCurrentProfile);
      
    }

  ngOnInit(): void {
    this.store.dispatch(getProfileAction());
  }

}
