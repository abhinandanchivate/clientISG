import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ProfilesRoutingModule } from './profiles-routing.module';
import { CreateProfileComponent } from './components/forms/create-profile/create-profile.component';
import { AddEduComponent } from './components/forms/add-edu/add-edu.component';
import { AddExpComponent } from './components/forms/add-exp/add-exp.component';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { ProfileService } from './services/profile.service';
import { interceptorProviders } from '../shared/interceptors';
import { DisplayCurrentProfileComponent } from './components/pages/display-current-profile/display-current-profile.component';
import { DisplaySkillsComponent } from './components/pages/display-current-profile/display-skills/display-skills.component';


@NgModule({
  declarations: [
    CreateProfileComponent,
    AddEduComponent,
    AddExpComponent,
    DisplayCurrentProfileComponent,
    DisplaySkillsComponent
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    HttpClientModule,
    ProfilesRoutingModule
  ],
  providers: [
    ProfileService,
    ...interceptorProviders
  ]
})
export class ProfilesModule { }
