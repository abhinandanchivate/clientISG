import { ISocialNetwork } from "./isocial-network";

export interface IProfile {
    id?: string;
    status: string;
    company?: string;
    website?: string;
    location?: string;
    skills: string;
    githubusername?: string;
    bio?: string;
    social? : ISocialNetwork;
}


export interface SocialLinks {
    youtube?: string; // Optional field, as it can be empty
    twitter?: string; // Optional field, as it can be empty
    instagram?: string; // Optional field, as it can be empty
    linkedin?: string; // Optional field, as it can be empty
    facebook?: string; // Optional field, as it can be empty
  }

export type ProfileDetails = ProfileProps;
  
export interface ProfileProps {
    social: SocialLinks;
    skills: string[]; // Array of strings for skills
    _id: string; // MongoDB ObjectId
    user: string; // MongoDB ObjectId referencing the user
    __v: number; // Version key for Mongoose
    bio: string; // User's bio
    company: string; // Company name
    date: string; // ISO 8601 date string
    education: any[]; // Array for education, adjust type if needed
    experience: any[]; // Array for experience, adjust type if needed
    githubusername: string; // GitHub username
    location: string; // User's location
    status: string; // Professional status
    website?: string; // Optional website URL
  }