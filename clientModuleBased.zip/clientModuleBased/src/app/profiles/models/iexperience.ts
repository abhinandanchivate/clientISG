import { ICommonProfile } from "./icommonprofile";


export interface IExperience {
    title: string;
    company: string;
    location?: string;
    commonProfile: ICommonProfile;
}

