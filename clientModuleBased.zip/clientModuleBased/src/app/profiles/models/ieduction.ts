import { ICommonProfile } from "./icommonprofile";


export interface IEducation {
    school: string;
    degree: string;
    fieldofstudy?: string;
    commonProfile: ICommonProfile;
}

