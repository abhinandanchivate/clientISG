
export interface ICommonProfile {
    from?: string;
    to?: string;
    current?: boolean;
    description?: string;
}
