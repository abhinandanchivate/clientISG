import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CreateProfileComponent } from './components/forms/create-profile/create-profile.component';
import { AddEduComponent } from './components/forms/add-edu/add-edu.component';
import { AddExpComponent } from './components/forms/add-exp/add-exp.component';
import { DisplayCurrentProfileComponent } from './components/pages/display-current-profile/display-current-profile.component';

const routes: Routes = [{
  path: 'create-profile',
  component: CreateProfileComponent
},
{
  path: 'add-edu',
  component: AddEduComponent
},
{
  path: 'add-exp',
  component: AddExpComponent
},
{
  path: 'display-profile',
  component: DisplayCurrentProfileComponent
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ProfilesRoutingModule { }
