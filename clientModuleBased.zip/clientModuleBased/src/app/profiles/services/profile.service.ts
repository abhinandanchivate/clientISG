import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { IProfile, ProfileProps } from '../models/iprofile';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProfileService {

  constructor(private httpClient: HttpClient) { }

  getProfile() : Observable<ProfileProps> {
    return this.httpClient.get<ProfileProps>('unique/profile/me');
  }
  
  createProfile(profile: IProfile) : Observable<ProfileProps>{
    return this.httpClient.post<ProfileProps>('/unique/profile', profile);
  }
}
