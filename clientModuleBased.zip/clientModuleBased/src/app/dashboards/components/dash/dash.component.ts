import { Component, OnInit } from '@angular/core';
import { AppState } from '../../../globalstate/app.state';
import { Store } from '@ngrx/store';
import { getProfileAction } from '../../../profiles/state/profiles.action';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { ProfileDetails } from '../../../profiles/models/iprofile';
import { selectCurrentProfile } from '../../../profiles/state/profiles.selectors';

@Component({
  selector: 'app-dash',
  templateUrl: './dash.component.html',
  styleUrl: './dash.component.css'
})
export class DashComponent implements OnInit {

  profile$: Observable<ProfileDetails| null>
  constructor(private store: Store<{app: AppState}>, private router: Router) { 
    this.profile$ = this.store.select(selectCurrentProfile);
   }

  ngOnInit(): void {
   this.store.dispatch(getProfileAction());
  }

  onSubmited(){
    this.router.navigate(['/profiles/create-profile']);
  }
}
