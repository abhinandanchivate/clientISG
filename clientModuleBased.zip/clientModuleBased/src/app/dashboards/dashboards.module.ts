import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DashboardsRoutingModule } from './dashboards-routing.module';
import { DashComponent } from './components/dash/dash.component';
import { interceptorProviders } from '../shared/interceptors';
import { ProfileService } from '../profiles/services/profile.service';
import { HttpClientModule } from '@angular/common/http';


@NgModule({
  declarations: [
    DashComponent
  ],
  imports: [
    CommonModule,
    HttpClientModule,
    DashboardsRoutingModule
  ],
  providers: [
    // Add services here
    ProfileService,
    ...interceptorProviders
  ]
})
export class DashboardsModule { }
