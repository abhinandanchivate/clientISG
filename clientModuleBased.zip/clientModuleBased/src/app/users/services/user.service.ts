import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { IUser } from '../models/iuser';
import { Observable, shareReplay } from 'rxjs';
import { ILogin } from '../models/ilogin';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  constructor(private httpClient:HttpClient) { }
  addUser = (user: IUser) => this.httpClient.post('/unique/users', user);
  loginUser = (user: ILogin) => this.httpClient.post('/unique/auth', user);
  isLoggedIn = () : Observable<IUser>=> this.httpClient.get<IUser>('/unique/auth');
}
