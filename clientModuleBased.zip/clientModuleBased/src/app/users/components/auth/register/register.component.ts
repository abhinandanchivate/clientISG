import { Component } from '@angular/core';

import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { IUser } from '../../../models/iuser';
import { UserService } from '../../../services/user.service';
import { Router } from '@angular/router';
import { AppState } from '../../../../globalstate/app.state';
import { Store } from '@ngrx/store';
import { registerAction } from '../../../state/users.action';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {
  iUser: IUser = {name: '', email: '', password: '', confirmPassword: ''};
  registratorForm: FormGroup;
  // fb: used to build Reactive Form instance. only 1 always
  constructor(private fb: FormBuilder,      
              private store: Store<{app: AppState}>,         
              private router: Router) { 
    this.registratorForm = this.fb.group({
      name: ["", [Validators.required]],
      email: ["", [Validators.required, Validators.email]],
      password:["", [Validators.required, Validators.minLength(6)]],
      confirmPassword: ["", [Validators.required, Validators.minLength(6)]]
    },
    {
      // TODO: Add custom validator to check if password and confirmPassword match
      // Validators: [this.passwordMatchValidator]
      
    }); 
  }

  // will handle the form submission
  onSubmit() {
    if(this.onCheckValidForm()){
      
      // Destructing the form values
      const {name, email, password, confirmPassword} = this.registratorForm.value;
      // localStorage.setItem('token', response.token);
      if(password != confirmPassword){
        console.log("Passwords do not match");
      } else{
        console.log(this.registratorForm.value);
        this.store.dispatch(registerAction({username: name, email, password}));
        this.router.navigate(['/dashboards']);
      }
      
    } else {
      console.log("Invalid form");
    }
  }
    
  onCheckValidForm(){
    return this.registratorForm.valid;
  }
}
