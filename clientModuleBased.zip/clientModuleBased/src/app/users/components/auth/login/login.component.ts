import { Component } from '@angular/core';
import { ILogin } from '../../../models/ilogin';
import { Form, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { UserService } from '../../../services/user.service';
import { Router } from '@angular/router';
import { AppState } from '../../../../globalstate/app.state';
import { Store } from '@ngrx/store';
import { loginAction } from '../../../state/users.action';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  iLogin: ILogin = {email: '', password: ''};
  loginForm : FormGroup;
  // fb: used to build Reactive Form instance. only 1 always
  constructor(private fb: FormBuilder,private store: Store<{app: AppState}>,private router: Router) { 
    this.loginForm = this.fb.group({
      email: ["", [Validators.required, Validators.email]],
      password: ["", [Validators.required, Validators.minLength(6)]]
    });
  }

  // will handle the form submission
  onSubmit() {
    if(this.onCheckValidForm()){
      console.log(this.loginForm.value);
      const {email, password} = this.loginForm.value;
      this.store.dispatch(loginAction({email, password}));      
      // this.userService.loginUser(this.loginForm.value).subscribe(
      //   (response: any) => { 
      //     console.log(response) 
      //     localStorage.setItem('token', response.token);
      //     this.router.navigate(['/dashboards']);
      //   },
      //   (error) => {
          
      //   }
      // );
    } else {
      console.log("Invalid form");
    }
  }
    
  onCheckValidForm(){
    return this.loginForm.valid;
  }
}
