export interface loginProps {
    email: string;
    password: string;
}