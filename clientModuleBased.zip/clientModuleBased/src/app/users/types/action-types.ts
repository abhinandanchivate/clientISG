// Define the constants for the action types
// i.e. [Users] RegisterAction, [Users] Register Success, [Users] Register Fail in const variables for code maintainability

export const USER_ACTION_TYPES = {
    "REGISTER_SUCCESS" : "[Users] Register Success",
    "REGISTER_FAIL" : "[Users] Register Fail",
    "REGISTER_ACTION" : "[Users] RegisterAction", 
    "LOGIN_SUCCESS" : "[Users] Login Success",
    "LOGIN_FAIL" : "[Users] Login Fail",
    "LOGIN_ACTION" : "[Users] LoginAction", 
}