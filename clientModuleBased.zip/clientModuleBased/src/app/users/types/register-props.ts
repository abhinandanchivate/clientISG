import { loginProps } from "./login-props";

export interface registerProps extends loginProps {
    username: string;
}