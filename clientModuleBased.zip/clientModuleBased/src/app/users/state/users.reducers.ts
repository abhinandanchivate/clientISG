import { createReducer, on } from "@ngrx/store";
import { initialUsersState, UsersState } from "../../users/state/users.state";
import { loginAction, loginActionFail, loginActionSuccess, registerAction, registerActionFail, registerActionSuccess } from "./users.action";


export const userReducer = createReducer(initialUsersState,
    on(registerAction, loginAction ,(userState: UsersState) => ({
        ...userState, // data which we get for the rest calls
        loading: false, 
        error: null,        
    })),
    on(registerActionSuccess, loginActionSuccess ,(state: UsersState) => ({        
        ...state, // data which we get for the rest calls
        isAuthenticated: true,
        loading: false, 
        error: null,
    })), 
    on(registerActionFail, loginActionFail, (state: UsersState) => ({
        ...state, // copy the current state
        loading: true,
        isAuthenticated: false
    })),    
);