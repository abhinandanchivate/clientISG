import { Actions, createEffect } from '@ngrx/effects';
import { UserService } from '../services/user.service';
import { Router } from '@angular/router';
import { Injectable } from '@angular/core';
import { ofType } from '@ngrx/effects';
import {
    loginAction,
  loginActionFail,
  loginActionSuccess,
  registerAction,
  registerActionFail,
  registerActionSuccess,
} from './users.action';
import { catchError, map, of, switchMap } from 'rxjs';
import { IUser } from '../models/iuser';

@Injectable()
export class UsersEffect {
  constructor(
    private action$: Actions,
    private userService: UserService,
    private router: Router
  ) {}

  // create Effect creates an side effect that listens to the action.
  registerAction$ = createEffect(() => {
    return this.action$.pipe(
      ofType(registerAction), // listens to the action
      switchMap(({ username, email, password }) => {
        const user: IUser = {
          name: username,
          email: email,
          password: password,
        };
        return this.userService.addUser(user).pipe(
          map((response: any) => {
            localStorage.setItem('token', response.token);
            return registerActionSuccess({ response })
          }),
          catchError((errorResponse) =>
            of(registerActionFail({ errorResponse }))
          )
        );
      })
    );
  });

  loginAction$ = createEffect(() => {
    return this.action$.pipe(
        ofType(loginAction),
        switchMap(({email, password}) => {
            return this.userService.loginUser({email: email, password: password}).pipe(
                map((response: any) => {
                    localStorage.setItem('token', response.token);
                    this.router.navigate(['/dashboards/']);
                    return  loginActionSuccess({ response })
                }),
                catchError((errorResponse) =>
                  of(loginActionFail({ errorResponse }))
                )
            );
        })
    )
  });
}
