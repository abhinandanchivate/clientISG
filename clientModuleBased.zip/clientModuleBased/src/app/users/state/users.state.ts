// Add the imports

// Add the interface
export interface UsersState {
  isAuthenticated : boolean;
  user: {
    name: string;
    email: string;    
    password?: string;
  };
  currentUser: {
    id: string;
    name: string;
    email: string;
    avatar?: string;
  };
  loading: boolean;
  token?: string;
}

// Add the initial state
export const initialUsersState: UsersState = {
  isAuthenticated: false,
  user: {
    name: '',
    email: '',
    password: '',
  },
  currentUser: {
    id: '',
    name: '',
    email: '',
    avatar: '',
  },
  loading: false,
  token:  localStorage.getItem('token') || '',
};
