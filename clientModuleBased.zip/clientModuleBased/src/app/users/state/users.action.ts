import { createAction, props } from "@ngrx/store";
import { registerProps } from "../types/register-props";
import { loginProps } from "../types/login-props";


// 
export const registerAction = createAction('[Users] RegisterAction', props<registerProps>());
export const registerActionSuccess = createAction('[Users] Register Success', props<{response: any}>());
export const registerActionFail = createAction('[Users] Register Fail', props<{errorResponse: any}>());

export const loginAction = createAction('[Users] LoginAction', props<loginProps>());
export const loginActionSuccess = createAction('[Users] Login Success', props<{response: any}>());  
export const loginActionFail = createAction('[Users] Login Fail', props<{errorResponse: any}>());