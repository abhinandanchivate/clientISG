import { ProfileState } from "../profiles/state/profiles.state";
import { UsersState } from "../users/state/users.state";


export interface AppState {
    user: UsersState;
    // this variableName should be used in the  
	// when we create the selector for profileState
    profile: ProfileState;
}

