import { ActionReducerMap } from "@ngrx/store";
import { AppState } from "./app.state";
import { userReducer } from "../users/state/users.reducers";
import { profileReducer } from "../profiles/state/profiles.reducers";


export const appReducer : ActionReducerMap<AppState> =  {
    user: userReducer,
    profile: profileReducer
}

