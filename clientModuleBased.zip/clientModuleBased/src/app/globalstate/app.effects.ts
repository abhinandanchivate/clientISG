import { ProfileEffect } from "../profiles/state/profiles.effects";
import { UsersEffect } from "../users/state/users.effects";


export const appEffects = [UsersEffect, ProfileEffect]; // Add the ProfileEffect to the array
