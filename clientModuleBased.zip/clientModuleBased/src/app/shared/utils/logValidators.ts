import { FormGroup } from "@angular/forms";

export function logValidationErrors(formGroup: FormGroup) : void{
    Object.keys(formGroup.controls).forEach((field) => {      
      const control: any = formGroup.get(field);
      if(control instanceof FormGroup){
        logValidationErrors(control);
      }
      else if(control && control?.invalid){
        console.log('Field: ', field, ' | Error: ', control?.errors);
      }
    })
  }