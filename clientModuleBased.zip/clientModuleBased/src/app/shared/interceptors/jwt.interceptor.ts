import {
  HttpEvent,
  HttpHandler,
  HttpInterceptor,
  HttpInterceptorFn,
  HttpRequest,
} from '@angular/common/http';
import { Inject, Injectable } from '@angular/core';
import { Observable, tap } from 'rxjs';

// export const jwtInterceptor: HttpInterceptorFn = (req, next) => {
//   return next(req);
// };

@Injectable()
export class JwtInterceptor implements HttpInterceptor {
  intercept(
    req: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    // req manipulatation before return statement
    // pipe is used for manipulated the request.
    // we cannot manipulate the request directly.
    // req.clone : we will use the existing request and create a new request.
    console.log('JwtInterceptor - ' + req.url);
    if(req.method === 'POST'  && (req.url.includes('auth')  || req.url.includes('register'))) {
      console.log('JwtInterceptor - Skipping token');
    } else {
        const token = localStorage.getItem('token');
        console.log('JwtInterceptor - Token: ' + token);
        req = req.clone({
            setHeaders: {
              'x-auth-token': `${token}`,
            },
          });
    }     

    return next.handle(req).pipe(tap({
      next: () => {
        console.log('JwtInterceptor - Next');
      },
      error: () => {
        console.log('JwtInterceptor - Error');
      },
    }));
  }
}
