import { HTTP_INTERCEPTORS } from "@angular/common/http";
import { JwtInterceptor } from "./jwt.interceptor";
import { LogInterceptor } from "./log.interceptor";


export const interceptorProviders = [
    {
        provide: HTTP_INTERCEPTORS,
        useClass: LogInterceptor,
        multi: true
    },
    {
        provide: HTTP_INTERCEPTORS,
        useClass: JwtInterceptor,
        multi: true
    },
]