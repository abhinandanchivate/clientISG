import { inject, } from '@angular/core';

import { catchError, map, Observable, of, tap } from 'rxjs';
import { UserService } from '../../users/services/user.service';
import { CanActivateFn } from '@angular/router';
export const authGuard: CanActivateFn = (route, state) => {
  const userService = inject(UserService);

  let token = localStorage.getItem('token') || '';
  console.log('AuthGuard - Token: ' + token);
  if(token) return true;

  return userService.isLoggedIn().pipe(
    map((response) => {
      if (response) {
        console.log('AuthGuard - User is logged in');
        return true;        
      } 
      else {
        console.log('AuthGuard - User is not logged in');
        return false
      }
    }),
    catchError((error) => {
      console.log('AuthGuard - User is not logged in');
      return of(false); 
    })
  );    
};
